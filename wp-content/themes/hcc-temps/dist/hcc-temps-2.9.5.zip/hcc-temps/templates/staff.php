<?php
/**
 * Template Name: Staff portal
 */
defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	$here = isset( $_GET['candidate'] ) ? hcc_staff_url( array( 'candidate' => absint( $_GET['candidate'] ) ) ) : get_permalink(); // phpcs:ignore WordPress.Security.NonceVerification
	wp_safe_redirect( add_query_arg( 'redirect_to', rawurlencode( $here ), hcc_login_url( true ) ) );
	exit;
}
if ( ! hcc_is_staff() ) {
	wp_safe_redirect( hcc_portal_url() );
	exit;
}
$cid  = isset( $_GET['candidate'] ) ? absint( $_GET['candidate'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
if ( $cid ) {
	wp_cache_delete( $cid, 'post_meta' ); // Force a live read of this candidate: some hosts serve stale post meta from a persistent object cache.
}
$view = $cid && 'hcc_applicant' === get_post_type( $cid ) ? 'folder' : ( isset( $_GET['view'] ) && in_array( $_GET['view'], apply_filters( 'hcc_staff_views', array( 'team', 'training', 'messages' ) ), true ) ? sanitize_key( $_GET['view'] ) : 'dash' ); // phpcs:ignore WordPress.Security.NonceVerification
$msg  = isset( $_GET['msg'] ) ? sanitize_key( $_GET['msg'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$msgs = array(
	'approved' => 'Approved. Added to the update for the candidate.', 'queued' => 'Added to the update for the candidate. Press "Preview and send" when you are ready.', 'note' => 'Saved to the profile.', 'sent' => 'Update email sent to the candidate.',
	'check' => 'Check saved.', 'check_result' => 'Choose a result before saving the check.', 'ref' => 'Reference details saved.', 'need_note' => 'Please add a note before marking this complete.', 'override_done' => 'Items marked complete.',
	'finished' => 'Onboarding finished. Moved to Staff completed.', 'cant_finish' => 'Finish needs: profile 100%, declaration sent and signed, and no unsent updates.', 'closed' => 'Application closed and moved to Withdrawn / not qualified.', 'reopened' => 'Application reopened.',
	'close_need' => 'Add a reason and your name to close the application.', 'staff_added' => 'Staff member added. They have been emailed a link to set their password.', 'staff_exists' => 'There is already an account with that email.', 'error' => 'Something went wrong. Please try again.', 'nothing' => 'Tick at least one item first.', 'train_none' => 'Tick at least one course for the training reminder.', 'email_changed' => 'Email changed. The candidate logs in with the new address; both addresses were told.', 'email_taken' => 'Another account already uses that email.', 'email_email' => 'That is not a valid email address.', 'email_same' => 'That is already the candidate\'s email.', 'email_user' => 'This registration has no login to update.', 'approved_some' => 'Uploaded items approved. Items with nothing uploaded were skipped: use "Mark complete (override)" for those.', 'exp_ok' => 'Expiry date saved and marked as checked.', 'exp_bad' => 'Enter a valid expiry date.', 'approve_none' => 'Nothing was approved: the ticked items have no upload. Use "Mark complete (override)" and add a note.',
);
$msgs     = apply_filters( 'hcc_staff_msgs', $msgs );
$form_url = esc_url( admin_url( 'admin-post.php' ) );
$me   = hcc_staff_name();
$role_label = function ( $aid ) { return hcc_role_name( hcc_meta( $aid, 'role_key' ) ); };
get_header();
?>
<main class="staff-page app-wrap">
<?php
$all_ids  = array_merge( hcc_desk_list( 'in_progress' ), hcc_desk_list( 'completed' ), hcc_desk_list( 'closed' ) );
$unread_n = count( array_filter( $all_ids, 'hcc_unread_msgs' ) );
$snav     = array(
	array( 'dash', 'Dashboard', 'home', hcc_staff_url() ),
	array( 'messages', 'Messages', 'chat', hcc_staff_url( array( 'view' => 'messages' ) ), $unread_n ? $unread_n : '' ),
	array( 'training', 'Training', 'grad', hcc_staff_url( array( 'view' => 'training' ) ) ),
);
$snav = apply_filters( 'hcc_staff_nav', $snav );
if ( hcc_is_manager() ) {
	$snav[] = array( 'sep', 'Manage' );
	$snav[] = array( 'team', 'Team', 'users', hcc_staff_url( array( 'view' => 'team' ) ) );
	$snav[] = array( 'settings', 'Website settings', 'cog', admin_url() );
}
hcc_app_open( array(
	'kind'    => 'staff',
	'title'   => 'Staff portal',
	'sub'     => 'Staff portal',
	'items'   => $snav,
	'current' => 'folder' === $view ? 'dash' : $view,
	'who'     => wp_get_current_user()->display_name,
	'logout'  => wp_logout_url( hcc_login_url( true ) ),
) );
?>
			<?php if ( isset( $msgs[ $msg ] ) ) : ?><p class="<?php echo in_array( $msg, array( 'train_none', 'cant_finish', 'need_note', 'close_need', 'check_result', 'staff_exists', 'error', 'nothing', 'approve_none', 'approved_some', 'email_taken', 'email_email', 'email_same', 'email_user', 'exp_bad', 'pack_need' ), true ) ? 'form-alert' : 'form-ok'; ?>" role="status"><?php echo esc_html( $msgs[ $msg ] ); ?></p><?php endif; ?>

<?php if ( has_action( 'hcc_staff_view_' . $view ) ) :
	do_action( 'hcc_staff_view_' . $view, $form_url, $me );
elseif ( 'dash' === $view ) :
	$search = hcc_field_get( 'q' );
	$tab    = in_array( hcc_field_get( 'tab' ), array( 'in_progress', 'completed', 'closed' ), true ) ? hcc_field_get( 'tab' ) : 'in_progress';
	$lists  = array( 'in_progress' => hcc_desk_list( 'in_progress', $search ), 'completed' => hcc_desk_list( 'completed', $search ), 'closed' => hcc_desk_list( 'closed', $search ) );
	$all_in = $search ? hcc_desk_list( 'in_progress' ) : $lists['in_progress'];
	$unsent = array_filter( $all_in, function ( $aid ) { return (bool) hcc_meta( $aid, 'queue' ); } );
	$review = array_filter( $all_in, function ( $aid ) { return hcc_meta( $aid, 'submitted' ) && hcc_counts( $aid, hcc_all_items( $aid ) )['review'] > 0; } );
	$done30 = array_filter( hcc_desk_list( 'completed' ), function ( $aid ) { $c = hcc_meta( $aid, 'completed' ); return is_array( $c ) && $c['at'] > time() - 30 * DAY_IN_SECONDS; } );
	$days   = array();
	foreach ( hcc_desk_list( 'completed' ) as $aid ) {
		$c = hcc_meta( $aid, 'completed' );
		$days[] = max( 0, ( $c['at'] - hcc_started( $aid ) ) / DAY_IN_SECONDS );
	}
	?>
			<div class="s-head" style="margin-top:0">
				<div><h1>Dashboard</h1><p>Candidates in onboarding, updates waiting to be sent, and completed staff.</p></div>
				<div class="s-actions"><a class="btn btn-ghost btn-sm" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=hcc_export&tab=' . $tab ), 'hcc_export' ) ); ?>">Export to Excel (CSV)</a></div>
			</div>
			<?php do_action( 'hcc_staff_dash_top' ); ?>
			<div class="kpis kpis-5">
				<div><b><?php echo count( $all_in ); ?></b><span>In progress</span></div>
				<div><b><?php echo count( $review ); ?></b><span>With files to review</span></div>
				<div class="<?php echo $unsent ? 'warn' : ''; ?>"><b><?php echo count( $unsent ); ?></b><span>Candidates with updates not sent</span></div>
				<div><b><?php echo count( $done30 ); ?></b><span>Completed (30 days)</span></div>
				<div><b><?php echo $days ? esc_html( number_format( array_sum( $days ) / count( $days ), 1 ) ) . ' days' : '—'; ?></b><span>Average start to sign-off</span></div>
			</div>

			<div class="p-card unsent<?php echo $unsent ? ' has' : ''; ?>" id="unsent">
				<div class="p-card-head"><h2>Updates not sent <span class="tray-n"><?php echo count( $unsent ); ?></span></h2><span class="p-count">Changes made in a candidate folder but not emailed yet</span></div>
				<?php if ( $unsent ) : ?>
					<div class="d-table"><div class="d-row d-hd"><span>Candidate</span><span>Changes</span><span>Made by</span><span>Waiting</span><span></span></div>
					<?php foreach ( $unsent as $aid ) : $q = (array) hcc_meta( $aid, 'queue' ); $first = reset( $q ); ?>
						<div class="d-row"><span><b><?php echo esc_html( hcc_name( $aid ) ); ?></b><small><?php echo esc_html( hcc_meta( $aid, 'ref' ) . ' · ' . $role_label( $aid ) ); ?></small></span><span data-l="Changes"><?php echo count( $q ); ?> change<?php echo count( $q ) > 1 ? 's' : ''; ?></span><span data-l="Made by"><?php echo esc_html( implode( ', ', array_unique( wp_list_pluck( $q, 'by' ) ) ) ); ?></span><span data-l="Waiting" class="<?php echo time() - $first['at'] > DAY_IN_SECONDS ? 'late' : ''; ?>"><?php echo esc_html( hcc_ago( $first['at'] ) ); ?></span><span><a class="btn btn-sun btn-sm" href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $aid ) ) ); ?>#tray">Open and send</a></span></div>
					<?php endforeach; ?></div>
				<?php else : ?><p class="hint">All updates have been sent.</p><?php endif; ?>
			</div>

			<?php
			$with_msgs = array_filter( array_merge( $all_in, hcc_desk_list( 'completed' ), hcc_desk_list( 'closed' ) ), 'hcc_unread_msgs' );
			if ( $with_msgs ) : ?>
				<div class="p-card unsent has" id="newmsgs" style="border-color:var(--pink)">
					<div class="p-card-head"><h2>New messages <span class="tray-n" style="background:var(--pink);color:#fff"><?php echo count( $with_msgs ); ?></span></h2><span class="p-count">From candidates, not opened yet</span></div>
					<div class="d-table"><div class="d-row d-hd"><span>Candidate</span><span>Message</span><span>Received</span><span></span><span></span></div>
					<?php foreach ( $with_msgs as $aid ) : $cm = (array) hcc_meta( $aid, 'cmsgs' ); $last = end( $cm ); ?>
						<div class="d-row"><span><b><?php echo esc_html( hcc_name( $aid ) ); ?></b><small><?php echo esc_html( hcc_meta( $aid, 'ref' ) . ' · ' . hcc_unread_msgs( $aid ) . ' new' ); ?></small></span><span data-l="Message"><?php echo esc_html( mb_strimwidth( $last['text'], 0, 80, '…' ) ); ?></span><span data-l="Received"><?php echo esc_html( hcc_ago( (int) $last['at'] ) ); ?></span><span></span><span><a class="btn btn-sm btn-navy" href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $aid ) ) ); ?>#messages">Open and reply</a></span></div>
					<?php endforeach; ?></div>
				</div>
			<?php endif; ?>
			<form class="d-tabs" method="get" action="<?php echo esc_url( hcc_staff_url() ); ?>">
				<?php foreach ( array( 'in_progress' => 'In progress', 'completed' => 'Staff completed', 'closed' => 'Withdrawn / not qualified' ) as $k => $l ) : ?>
					<a role="tab" aria-selected="<?php echo $k === $tab ? 'true' : 'false'; ?>" href="<?php echo esc_url( add_query_arg( array_filter( array( 'tab' => $k, 'q' => $search ) ), hcc_staff_url() ) ); ?>"><?php echo esc_html( $l ); ?> (<?php echo count( $lists[ $k ] ); ?>)</a>
				<?php endforeach; ?>
				<input type="hidden" name="tab" value="<?php echo esc_attr( $tab ); ?>">
				<input type="search" name="q" value="<?php echo esc_attr( $search ); ?>" placeholder="Search name, reference, role, email or phone" aria-label="Search candidates">
			</form>
			<div class="p-card"><div class="d-table">
				<?php if ( 'in_progress' === $tab ) : ?>
					<div class="d-row d-hd d-prog"><span>Candidate</span><span>Started</span><span>Stage</span><span>Profile</span><span>Missing</span><span>Last activity</span></div>
					<?php foreach ( $lists['in_progress'] as $aid ) :
						$c   = hcc_counts( $aid, hcc_all_items( $aid ) );
						$pct = hcc_progress( $aid );
						$dup = ! hcc_meta( $aid, 'dup_ok' ) && hcc_duplicates( $aid );
						$stage = hcc_meta( $aid, 'submitted' ) ? hcc_meta( $aid, 'stage', 'Documents' ) : 'Registering (step ' . (int) hcc_meta( $aid, 'step', 1 ) . ' of 7)';
						?>
						<a class="d-row d-prog" href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $aid ) ) ); ?>"><span><b><?php echo esc_html( hcc_name( $aid ) ); ?></b><?php echo $dup ? ' <em class="dup-tag">possible duplicate</em>' : ''; ?><?php echo hcc_meta( $aid, 'queue' ) ? ' <em class="unsent-tag">update not sent</em>' : ''; ?><?php echo hcc_unread_msgs( $aid ) ? ' <em class="new-msg-tag">new message</em>' : ''; ?><small><?php echo esc_html( hcc_meta( $aid, 'ref' ) . ' · ' . $role_label( $aid ) ); ?></small></span><span data-l="Started"><?php echo esc_html( wp_date( 'j M Y', hcc_started( $aid ) ) ); ?></span><span data-l="Stage"><?php echo esc_html( $stage ); ?></span><span data-l="Profile"><span class="mini-bar"><i style="width:<?php echo (int) $pct; ?>%"></i></span><?php echo (int) $pct; ?>%</span><span data-l="Missing"><?php echo (int) $c['todo']; ?></span><span data-l="Last activity"><?php echo esc_html( hcc_ago( hcc_last_activity( $aid ) ) ); ?></span></a>
					<?php endforeach; ?>
				<?php else : ?>
					<div class="d-row d-hd d-done"><span>Candidate</span><span>Application started</span><span><?php echo 'completed' === $tab ? 'Signed off' : 'Closed'; ?></span><span><?php echo 'completed' === $tab ? 'Days' : 'Outcome'; ?></span><span>Signed off by</span><span></span></div>
					<?php foreach ( $lists[ $tab ] as $aid ) :
						$e = hcc_meta( $aid, 'completed' === $tab ? 'completed' : 'closed' );
						$e = is_array( $e ) ? $e : array( 'at' => 0, 'by' => '' );
						?>
						<div class="d-row d-done"><span><b><?php echo esc_html( hcc_name( $aid ) ); ?></b><?php echo hcc_unread_msgs( $aid ) ? ' <em class="new-msg-tag">new message</em>' : ''; ?><small><?php echo esc_html( hcc_meta( $aid, 'ref' ) . ' · ' . $role_label( $aid ) . ( ! empty( $e['why'] ) ? ' · ' . $e['why'] : '' ) ); ?></small></span><span data-l="Started"><?php echo esc_html( wp_date( 'j M Y', hcc_started( $aid ) ) ); ?></span><span data-l="<?php echo 'completed' === $tab ? 'Signed off' : 'Closed'; ?>"><?php echo esc_html( wp_date( 'j M Y', (int) $e['at'] ) ); ?></span><span data-l="<?php echo 'completed' === $tab ? 'Days' : 'Outcome'; ?>"><?php echo esc_html( 'completed' === $tab ? max( 0, round( ( $e['at'] - hcc_started( $aid ) ) / DAY_IN_SECONDS ) ) : $e['outcome'] ); ?></span><span data-l="By"><?php echo esc_html( $e['by'] ); ?></span><span><a class="link-btn" href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $aid ) ) ); ?>">Open file</a></span></div>
					<?php endforeach; ?>
				<?php endif; ?>
				<?php if ( ! $lists[ $tab ] ) : ?><p class="hint" style="padding:12px 6px">No candidates here<?php echo $search ? ' matching "' . esc_html( $search ) . '"' : ''; ?>.</p><?php endif; ?>
			</div></div>

<?php elseif ( 'messages' === $view ) :
	$mq      = hcc_field_get( 'q' );
	$mtab    = isset( $_GET['mt'] ) && 'all' === $_GET['mt'] ? 'all' : 'unread'; // phpcs:ignore WordPress.Security.NonceVerification
	$open_id = isset( $_GET['convo'] ) ? absint( $_GET['convo'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	if ( $open_id && 'hcc_applicant' !== get_post_type( $open_id ) ) {
		$open_id = 0;
	}
	if ( $open_id ) {
		$open_unread = hcc_unread_msgs( $open_id );
		if ( $open_unread ) {
			hcc_set( $open_id, 'cmsg_seen', time() );
			hcc_log( $open_id, 'Opened ' . $open_unread . ' new message' . ( $open_unread > 1 ? 's' : '' ) . ' from the candidate' );
		}
	}
	$convos = array();
	foreach ( $all_ids as $aid ) {
		$thread = hcc_thread( $aid );
		if ( ! $thread ) {
			continue;
		}
		if ( $mq ) {
			$hay = strtolower( hcc_name( $aid ) . ' ' . hcc_meta( $aid, 'ref' ) . ' ' . hcc_meta( $aid, 'email' ) );
			if ( false === strpos( $hay, strtolower( $mq ) ) ) {
				continue;
			}
		}
		$convos[ $aid ] = array( 'last' => end( $thread ), 'new' => hcc_unread_msgs( $aid ), 'n' => count( $thread ) );
	}
	uasort( $convos, function ( $a, $b ) { return ( $b['new'] > 0 ) - ( $a['new'] > 0 ) ?: $b['last']['at'] - $a['last']['at']; } );
	$unread_c = array_filter( $convos, function ( $c ) { return $c['new'] > 0; } );
	$show     = 'all' === $mtab ? $convos : $unread_c;
	$keepmt   = 'all' === $mtab ? 'all' : null;
	?>
			<div class="s-head" style="margin-top:0"><div><h1>Messages</h1><p>Chat with candidates. Open a conversation to read it and reply — your reply is sent straight away (email and text), and also appears in the candidate's file.</p></div></div>
			<div class="msg-layout<?php echo $open_id ? ' has-open' : ''; ?>">
				<div class="msg-list">
					<form class="d-tabs" method="get" action="<?php echo esc_url( hcc_staff_url() ); ?>">
						<input type="hidden" name="view" value="messages">
						<a role="tab" aria-selected="<?php echo 'unread' === $mtab ? 'true' : 'false'; ?>" href="<?php echo esc_url( add_query_arg( array_filter( array( 'view' => 'messages', 'q' => $mq ) ), hcc_staff_url() ) ); ?>">Unread (<?php echo count( $unread_c ); ?>)</a>
						<a role="tab" aria-selected="<?php echo 'all' === $mtab ? 'true' : 'false'; ?>" href="<?php echo esc_url( add_query_arg( array_filter( array( 'view' => 'messages', 'mt' => 'all', 'q' => $mq ) ), hcc_staff_url() ) ); ?>">All (<?php echo count( $convos ); ?>)</a>
						<input type="search" name="q" value="<?php echo esc_attr( $mq ); ?>" placeholder="Search name, ref or email" aria-label="Search messages">
						<?php if ( 'all' === $mtab ) : ?><input type="hidden" name="mt" value="all"><?php endif; ?>
					</form>
					<div class="p-card msg-rows">
						<?php if ( $show ) : ?>
							<?php foreach ( $show as $aid => $c ) : $l = $c['last']; ?>
								<a class="msg-item<?php echo $c['new'] ? ' is-new' : ''; ?><?php echo $aid === $open_id ? ' is-open' : ''; ?>" href="<?php echo esc_url( add_query_arg( array_filter( array( 'view' => 'messages', 'mt' => $keepmt, 'q' => $mq, 'convo' => $aid ) ), hcc_staff_url() ) ); ?>#reply">
									<span class="msg-item-top"><b><?php echo esc_html( hcc_name( $aid ) ); ?></b><?php echo $c['new'] ? ' <em class="new-msg-tag">' . (int) $c['new'] . '</em>' : ''; ?><small><?php echo esc_html( hcc_ago( (int) $l['at'] ) ); ?></small></span>
									<span class="msg-item-sub"><?php echo esc_html( ( 'cand' === $l['from'] ? hcc_meta( $aid, 'first' ) : 'You' ) . ': ' . mb_strimwidth( wp_strip_all_tags( (string) $l['text'] ), 0, 64, '…' ) ); ?></span>
								</a>
							<?php endforeach; ?>
						<?php else : ?>
							<p class="hint" style="padding:14px 8px"><?php echo $mq ? 'No conversations matching "' . esc_html( $mq ) . '".' : ( 'all' === $mtab ? 'No candidate has sent a message yet.' : 'No unread messages. You are all caught up.' ); ?><?php if ( 'unread' === $mtab && $convos ) : ?> <a href="<?php echo esc_url( hcc_staff_url( array( 'view' => 'messages', 'mt' => 'all' ) ) ); ?>">See all</a><?php endif; ?></p>
						<?php endif; ?>
					</div>
				</div>
				<div class="msg-convo p-card" id="reply">
					<?php if ( $open_id ) : $othread = hcc_thread( $open_id ); ?>
						<div class="msg-convo-head">
							<a class="msg-back" href="<?php echo esc_url( add_query_arg( array_filter( array( 'view' => 'messages', 'mt' => $keepmt, 'q' => $mq ) ), hcc_staff_url() ) ); ?>">← All</a>
							<div class="msg-convo-who"><b><?php echo esc_html( hcc_name( $open_id ) ); ?></b><small><?php echo esc_html( hcc_meta( $open_id, 'ref' ) . ' · ' . $role_label( $open_id ) . ( 'closed' === hcc_state( $open_id ) ? ' · closed' : '' ) ); ?></small></div>
							<a class="btn btn-ghost btn-sm" href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $open_id ) ) ); ?>">Open file</a>
						</div>
						<?php if ( isset( $_GET['sent'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?><p class="msg-sent-ok">✓ Reply sent to <?php echo esc_html( hcc_meta( $open_id, 'first' ) ); ?>.</p><?php endif; ?>
						<?php if ( $othread ) : ?>
							<ol class="thread msg-thread">
								<?php foreach ( array_slice( $othread, -50 ) as $m ) : ?>
									<li class="<?php echo esc_attr( $m['from'] ); ?>"><span class="who"><?php echo esc_html( ( 'cand' === $m['from'] ? hcc_meta( $open_id, 'first' ) : $m['by'] ) . ' · ' . wp_date( 'j M, H:i', $m['at'] ) ); ?></span><?php echo nl2br( esc_html( $m['text'] ) ); ?></li>
								<?php endforeach; ?>
							</ol>
						<?php else : ?>
							<p class="hint">No messages yet with <?php echo esc_html( hcc_meta( $open_id, 'first' ) ); ?>. Send the first one below.</p>
						<?php endif; ?>
						<?php if ( 'closed' === hcc_state( $open_id ) ) : ?>
							<p class="hint">This application is closed. Reopen it from the candidate's file to message them.</p>
						<?php else : ?>
							<form method="post" action="<?php echo $form_url; ?>" class="msg-reply">
								<input type="hidden" name="action" value="hcc_msg_reply"><input type="hidden" name="candidate" value="<?php echo (int) $open_id; ?>"><?php wp_nonce_field( 'hcc_desk_' . $open_id, '_wpnonce', true ); ?>
								<label for="creply" class="screen-reader-text">Reply</label>
								<textarea id="creply" name="text" rows="2" placeholder="Reply to <?php echo esc_attr( hcc_meta( $open_id, 'first' ) ); ?>…" required></textarea>
								<button class="btn btn-navy" type="submit">Send</button>
							</form>
							<p class="form-note">Sent straight away by email and text, and saved to the candidate's file.</p>
						<?php endif; ?>
					<?php else : ?>
						<div class="msg-empty"><p>Select a conversation on the left to read it and reply.</p></div>
					<?php endif; ?>
				</div>
			</div>

<?php elseif ( 'training' === $view ) :
	$tlist   = hcc_training_list();
	$prev    = array_values( array_filter( array_map( 'absint', explode( ',', hcc_field_get( 'preview' ) ) ), function ( $x ) use ( $tlist ) { return isset( $tlist[ $x ] ); } ) );
	$tnote   = isset( $_GET['note'] ) ? sanitize_textarea_field( wp_unslash( rawurldecode( $_GET['note'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$sent_n  = isset( $_GET['sent'] ) ? absint( $_GET['sent'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification
	$links   = hcc_elearn_links();
	?>
			<div class="s-head" style="margin-top:0">
				<div><h1>Training</h1><p>Candidates who have submitted their registration and still have training certificates to come. Send them a reminder with links to buy the courses on the e-learning portal.</p></div>
				<?php if ( $links ) : ?><div class="s-actions"><a class="btn btn-ghost btn-sm" href="<?php echo esc_url( $links['login'] ); ?>" target="_blank" rel="noopener">Open the e-learning portal ↗</a></div><?php endif; ?>
			</div>
			<?php if ( null !== $sent_n ) : ?><p class="form-ok">Training reminder emailed to <?php echo (int) $sent_n; ?> candidate<?php echo 1 === $sent_n ? '' : 's'; ?>. Each email listed their own missing courses.</p><?php endif; ?>

			<?php if ( $prev ) :
				$first = $prev[0]; ?>
				<div class="p-card" id="preview" style="border:2px solid var(--sun)">
					<div class="p-card-head"><h2>Preview</h2><span class="p-count"><?php echo count( $prev ); ?> candidate<?php echo count( $prev ) > 1 ? 's' : ''; ?> selected</span></div>
					<p class="hint">Each candidate gets their own email listing only the courses they are missing. This is <?php echo esc_html( hcc_name( $first ) ); ?>'s:</p>
					<div class="email"><div class="email-meta"><span>To: <?php echo esc_html( hcc_meta( $first, 'email' ) ); ?></span><span>Subject: Action needed: training certificates for your HCC-Temps registration</span></div><div class="email-body">
						<p>Hi <?php echo esc_html( hcc_meta( $first, 'first' ) ); ?>,</p><p>To finish your registration as a <b><?php echo esc_html( hcc_role_name( hcc_meta( $first, 'role_key' ) ) ); ?></b>, we still need these training certificates:</p>
						<ul><?php foreach ( $tlist[ $first ] as $l ) : ?><li><?php echo esc_html( $l ); ?></li><?php endforeach; ?></ul>
						<?php if ( $tnote ) : ?><p style="background:var(--aqua-tint);padding:10px 14px;border-radius:10px"><?php echo nl2br( esc_html( $tnote ) ); ?></p><?php endif; ?>
						<p><b>You can buy these courses online</b> through our e-learning portal (Buy a course · Free trial · Log in). When you finish, download the certificate and upload it in your portal under Training.</p>
					</div></div>
					<form method="post" action="<?php echo $form_url; ?>" class="form-actions"><input type="hidden" name="action" value="hcc_train_bulk"><input type="hidden" name="step" value="send"><?php wp_nonce_field( 'hcc_train_bulk' ); ?>
						<?php foreach ( $prev as $x ) : ?><input type="hidden" name="ids[]" value="<?php echo (int) $x; ?>"><?php endforeach; ?>
						<input type="hidden" name="note" value="<?php echo esc_attr( $tnote ); ?>">
						<button class="btn btn-navy" type="submit">Send to <?php echo count( $prev ); ?> candidate<?php echo count( $prev ) > 1 ? 's' : ''; ?></button>
						<a class="link-btn" href="<?php echo esc_url( hcc_staff_url( array( 'view' => 'training' ) ) ); ?>">Cancel</a>
					</form>
				</div>
			<?php endif; ?>

			<form method="post" action="<?php echo $form_url; ?>" class="p-card" id="train-list"><input type="hidden" name="action" value="hcc_train_bulk"><input type="hidden" name="step" value="preview"><?php wp_nonce_field( 'hcc_train_bulk' ); ?>
				<div class="p-card-head"><h2>Missing training <span class="tray-n"><?php echo count( $tlist ); ?></span></h2><span class="p-count">Optional courses are included</span></div>
				<?php if ( ! $tlist ) : ?>
					<p class="hint">Nobody is waiting on training certificates right now.</p>
				<?php else : ?>
					<div class="d-table">
						<div class="d-row d-hd d-train"><span><label><input type="checkbox" id="tall" aria-label="Select all"></label></span><span>Candidate</span><span>Missing</span><span>Courses</span><span>Last reminder</span></div>
						<?php foreach ( $tlist as $x => $miss ) : $tr = hcc_meta( $x, 'train_reminded' ); ?>
							<div class="d-row d-train"><span><input type="checkbox" name="ids[]" value="<?php echo (int) $x; ?>"<?php checked( in_array( $x, $prev, true ) ); ?> aria-label="Select <?php echo esc_attr( hcc_name( $x ) ); ?>"></span><span><a href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $x ) ) ); ?>"><b><?php echo esc_html( hcc_name( $x ) ); ?></b></a><small><?php echo esc_html( hcc_meta( $x, 'ref' ) . ' · ' . $role_label( $x ) ); ?></small></span><span data-l="Missing"><b><?php echo count( $miss ); ?></b></span><span data-l="Courses"><?php echo esc_html( mb_strimwidth( implode( ', ', $miss ), 0, 120, '…' ) ); ?></span><span data-l="Last reminder"<?php echo is_array( $tr ) && $tr['at'] > time() - 3 * DAY_IN_SECONDS ? ' class="late" title="Reminded in the last 3 days"' : ''; ?>><?php echo is_array( $tr ) ? esc_html( hcc_ago( (int) $tr['at'] ) . ' · ' . $tr['by'] ) : 'Never'; ?></span></div>
						<?php endforeach; ?>
					</div>
					<div class="f full" style="margin-top:14px"><label for="bnote">Note to include (optional)</label><textarea id="bnote" name="note" placeholder="e.g. These are needed before we can offer you shifts."><?php echo esc_textarea( $tnote ); ?></textarea></div>
					<div class="form-actions"><button class="btn btn-navy" type="submit">Preview training reminders</button><span class="form-note">Nothing is sent until you press Send on the preview.</span></div>
				<?php endif; ?>
			</form>

<?php elseif ( 'team' === $view && hcc_is_manager() ) : ?>
			<div class="s-head" style="margin-top:0"><div><h1>Team</h1><p>People who can log in to the Staff portal. Managers can add staff and see bank details in full.</p></div></div>
			<div class="staff-grid">
				<div class="p-card"><div class="d-table">
					<div class="d-row d-hd"><span>Name</span><span>Email</span><span>Access</span><span></span><span></span></div>
					<?php foreach ( get_users( array( 'role__in' => array( 'hcc_staff', 'hcc_manager', 'administrator' ), 'orderby' => 'display_name' ) ) as $u ) : ?>
						<div class="d-row"><span><b><?php echo esc_html( $u->display_name ); ?></b></span><span><?php echo esc_html( $u->user_email ); ?></span><span><?php echo esc_html( in_array( 'hcc_staff', $u->roles, true ) ? 'Staff' : ( in_array( 'administrator', $u->roles, true ) ? 'Admin' : 'Manager' ) ); ?></span><span></span><span></span></div>
					<?php endforeach; ?>
				</div></div>
				<form class="p-card" method="post" action="<?php echo $form_url; ?>">
					<input type="hidden" name="action" value="hcc_add_staff"><?php wp_nonce_field( 'hcc_add_staff' ); ?>
					<div class="p-card-head"><h2>Add a staff member</h2></div>
					<div class="form-grid one">
						<div class="f"><label for="sf">First name</label><input type="text" id="sf" name="first" required></div>
						<div class="f"><label for="sl">Last name</label><input type="text" id="sl" name="last"></div>
						<div class="f"><label for="se">Email</label><input type="email" id="se" name="email" required></div>
						<fieldset class="f"><legend>Access</legend><div class="radios"><label class="radio"><input type="radio" name="level" value="staff" checked><span>Staff</span></label><label class="radio"><input type="radio" name="level" value="manager"><span>Manager</span></label></div></fieldset>
					</div>
					<div class="form-actions"><button class="btn btn-navy btn-sm" type="submit">Add and email invite</button></div>
				</form>
			</div>

<?php else :
	$aid      = $cid;
	$a       = (array) hcc_meta( $aid, 'answers', array() );
	$state   = hcc_state( $aid );
	$pct     = hcc_progress( $aid );
	$queue   = (array) hcc_meta( $aid, 'queue', array() );
	$review  = (array) hcc_meta( $aid, 'review', array() );
	$dnotes  = (array) hcc_meta( $aid, 'dnotes', array() );
	$dupes   = hcc_meta( $aid, 'dup_ok' ) ? array() : hcc_duplicates( $aid );
	$hidden  = '<input type="hidden" name="action" value="hcc_desk"><input type="hidden" name="candidate" value="' . (int) $aid . '">' . wp_nonce_field( 'hcc_desk_' . $aid, '_wpnonce', true, false );
	$ovkeys  = array_filter( array_map( 'sanitize_key', explode( ',', hcc_field_get( 'override' ) ) ) );
	$items   = hcc_all_items( $aid );
	$closed  = hcc_meta( $aid, 'closed' );
	$completed = hcc_meta( $aid, 'completed' );
	?>
			<?php
			$unread  = hcc_unread_msgs( $aid );
			$cdocs   = hcc_counts( $aid, hcc_items( $aid, 'docs' ) );
			$ctrain  = hcc_counts( $aid, hcc_items( $aid, 'train' ) );
			$chk_all = hcc_check_list( $aid );
			$chk_v   = (array) hcc_meta( $aid, 'checks', array() );
			$chk_n   = count( array_filter( array_keys( $chk_all ), function ( $k ) use ( $chk_v ) { return ! empty( $chk_v[ $k ]['result'] ); } ) );
			$refs_l  = hcc_refs( $aid );
			$refs_n  = count( array_filter( $refs_l, function ( $r ) { return ! empty( $r['recv'] ); } ) );
			$orders  = function_exists( 'hcc_orders' ) ? hcc_orders( $aid ) : array();
			$pay_n   = count( array_filter( $orders, function ( $o ) { return 'claimed' === $o['status']; } ) );
			$pay_due = count( array_filter( $orders, function ( $o ) { return 'due' === $o['status']; } ) );
			$pack    = function_exists( 'hcc_pack' ) ? hcc_pack( $aid ) : array();
			$pack_st = isset( $pack['status'] ) ? $pack['status'] : '';
			$sent_l  = (array) hcc_meta( $aid, 'messages', array() );
			$state_l = array( 'in_progress' => array( 'In progress', 'prog' ), 'completed' => array( 'Staff completed', 'ok' ), 'closed' => array( 'Withdrawn / not qualified', 'red' ) )[ $state ];
			$badge   = function ( $n, $cls = '' ) { return $n ? '<b class="cf-b' . ( $cls ? ' ' . $cls : '' ) . '">' . esc_html( $n ) . '</b>' : ''; };
			$fnav    = array(
				array( 'answers', 'Profile', '' ),
				array( 'sec-docs', 'Documents', $cdocs['review'] ? $badge( $cdocs['review'] ) : ( $cdocs['amend'] ? $badge( $cdocs['amend'], 'red' ) : '' ) ),
				array( 'sec-train', 'Training certificates', $ctrain['review'] ? $badge( $ctrain['review'] ) : ( $ctrain['todo'] ? $badge( $ctrain['todo'], 'red' ) : '' ) ),
				array( 'messages', 'Messages', $badge( $unread, 'pink' ) ),
				array( 'checks', 'Checks', $badge( $chk_n . '/' . count( $chk_all ), $chk_n === count( $chk_all ) ? 'ok' : 'grey' ) ),
				array( 'refs', 'References', $refs_l ? $badge( $refs_n . '/' . count( $refs_l ), $refs_n === count( $refs_l ) ? 'ok' : 'grey' ) : '' ),
				array( 'payments-card', 'Payments', $pay_n ? $badge( $pay_n . ' to confirm' ) : ( $pay_due ? $badge( 'Due', 'grey' ) : '' ) ),
				array( 'declaration', 'Signing pack', 'signed' === $pack_st ? $badge( 'Signed', 'ok' ) : ( 'sent' === $pack_st ? $badge( 'Sent', 'grey' ) : '' ) ),
				array( 'notes', 'Notes', '' ),
				array( 'sent', 'Sent updates', $badge( count( $sent_l ), 'grey' ) ),
				array( 'activity', 'Activity log', '' ),
			);
			?>
			<div class="crumbs cf-crumbs"><a href="<?php echo esc_url( hcc_staff_url() ); ?>">← Back to dashboard</a> / <?php echo esc_html( $state_l[0] ); ?></div>
			<div class="cf-head">
				<div class="cf-who">
					<span class="cf-ava" aria-hidden="true"><?php echo esc_html( strtoupper( mb_substr( (string) hcc_meta( $aid, 'first' ), 0, 1 ) ) ); ?></span>
					<div>
						<h1><?php echo esc_html( hcc_name( $aid ) ); ?> <span class="cf-pill cf-pill-<?php echo esc_attr( $state_l[1] ); ?>"><?php echo esc_html( $state_l[0] ); ?></span></h1>
						<p><?php echo esc_html( $role_label( $aid ) ); ?> · <b><?php echo esc_html( hcc_meta( $aid, 'ref' ) ); ?></b> · Registered <?php echo esc_html( wp_date( 'j M Y', hcc_started( $aid ) ) ); ?> · Last activity <?php echo esc_html( hcc_ago( hcc_last_activity( $aid ) ) ); ?><?php echo hcc_meta( $aid, 'submitted' ) ? '' : ' · <b>Still registering (step ' . (int) hcc_meta( $aid, 'step', 1 ) . ' of 7)</b>'; ?></p>
					</div>
				</div>
				<div class="pct cf-pct"><b>Profile <?php echo (int) $pct; ?>% complete</b><div class="progress"><i style="width:<?php echo (int) $pct; ?>%"></i></div><small><?php echo esc_html( ( $cdocs['ok'] + $ctrain['ok'] ) . ' of ' . ( $cdocs['need'] + $ctrain['need'] ) . ' items approved' ); ?></small></div>
				<div class="s-actions cf-acts">
					<form method="post" action="<?php echo $form_url; ?>" class="s-stage"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="stage"><label>Stage <select name="stage" onchange="this.form.submit()"><?php foreach ( hcc_stage_options() as $o ) : ?><option<?php selected( hcc_meta( $aid, 'stage' ), $o ); ?>><?php echo esc_html( $o ); ?></option><?php endforeach; ?></select></label><noscript><button class="btn btn-ghost btn-sm" type="submit">Set</button></noscript></form>
					<?php if ( 'in_progress' === $state ) : ?>
					<form method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="approve_all"><button class="btn btn-aqua btn-sm" type="submit">Approve all uploaded</button></form>
					<form method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="complete_all"><button class="btn btn-sun btn-sm" type="submit">Complete profile (100%)</button></form>
					<?php endif; ?>
					<a class="btn btn-ghost btn-sm" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=hcc_zip&a=' . $aid ), 'hcc_zip_' . $aid ) ); ?>">Download all (zip)</a>
					<a class="btn btn-ghost btn-sm" target="_blank" rel="noopener" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=hcc_report&a=' . $aid ), 'hcc_report_' . $aid ) ); ?>">Candidate report</a>
					<a class="btn btn-ghost btn-sm" target="_blank" rel="noopener" href="<?php echo esc_url( add_query_arg( 'preview', $aid, hcc_portal_url() ) ); ?>">View as candidate</a>
					<?php if ( $closed ) : ?>
						<form method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="reopen"><button class="btn btn-ghost btn-sm btn-red" type="submit">Reopen application</button></form>
					<?php elseif ( ! $completed ) : ?>
						<a class="btn btn-ghost btn-sm btn-red" href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $aid, 'closing' => 1 ) ) ); ?>#close">Withdrawn / not qualified</a>
					<?php else : ?>
						<form method="post" action="<?php echo $form_url; ?>" onsubmit="return confirm('Move this candidate back to In progress? The sign-off is removed and noted in the activity log.');"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="reopen"><button class="btn btn-ghost btn-sm" type="submit">Move back to in progress</button></form>
					<?php endif; ?>
				</div>
			</div>
					<div class="p-card tray cf-tray<?php echo $queue ? ' has' : ''; ?>" id="tray">
						<div class="cf-tray-head"><div class="cf-tray-t"><h2>Email update to <?php echo esc_html( hcc_meta( $aid, 'first' ) ); ?><?php echo $queue ? ': ' . count( $queue ) . ' change' . ( count( $queue ) > 1 ? 's' : '' ) . ' waiting' : ''; ?> <span class="tray-n"><?php echo count( $queue ); ?></span></h2><small><?php echo $queue ? 'They go in one email when you press Send. Nothing has been sent yet.' : 'No changes waiting. Approvals, replace requests, missing items and notes for the candidate collect here and go in one email.'; ?></small></div>
							<?php if ( $queue ) : ?><div class="cf-chips"><?php foreach ( array( 'approved' => array( '✓', 'approved', 'a' ), 'amend' => array( '↺', 'to replace', 'r' ), 'missing' => array( '!', 'still needed', 'r' ), 'training' => array( '🎓', 'training', 'n' ), 'note' => array( '✉', 'message', 'n' ) ) as $type => $ch ) : $nq = count( array_filter( $queue, function ( $q ) use ( $type ) { return $q['type'] === $type; } ) ); if ( $nq ) : ?><span class="cf-chip cf-chip-<?php echo esc_attr( $ch[2] ); ?>"><?php echo esc_html( $ch[0] . ' ' . $nq . ' ' . $ch[1] . ( 'message' === $ch[1] && $nq > 1 ? 's' : '' ) ); ?></span><?php endif; endforeach; ?></div><?php endif; ?>
						</div>
						<?php if ( $queue ) : ?><details class="tray-preview"><summary class="btn btn-sun btn-sm">Review and send</summary><div class="cf-tray-body"><?php
							foreach ( array( 'approved' => 'Approved', 'amend' => 'Please replace', 'missing' => 'Still needed from you', 'training' => 'Training still needed (can be bought online)', 'note' => 'Messages from our team' ) as $type => $title ) :
								$rows = array_filter( $queue, function ( $q ) use ( $type ) { return $q['type'] === $type; } );
								if ( ! $rows ) { continue; } ?>
								<div class="tray-g"><b><?php echo esc_html( $title ); ?></b><ul>
									<?php foreach ( $rows as $i => $q ) : ?><li><?php echo esc_html( trim( $q['label'] . ( $q['label'] && $q['text'] ? ': ' : '' ) . $q['text'] ) ); ?> <form method="post" action="<?php echo $form_url; ?>" class="inline"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="unqueue"><input type="hidden" name="i" value="<?php echo (int) $i; ?>"><button class="link-btn" type="submit">remove</button></form></li><?php endforeach; ?>
								</ul></div>
							<?php endforeach; ?>
							<p class="cf-sub">Email preview</p>
								<div class="email"><div class="email-meta"><span>To: <?php echo esc_html( hcc_meta( $aid, 'email' ) ); ?></span></div><div class="email-body">
									<p>Hi <?php echo esc_html( hcc_meta( $aid, 'first' ) ); ?>,</p><p>Here is an update on your registration (<?php echo esc_html( hcc_meta( $aid, 'ref' ) ); ?>):</p>
									<?php foreach ( array( 'approved' => 'Approved', 'amend' => 'Please replace', 'missing' => 'Still needed from you', 'training' => 'Training still needed (can be bought online)', 'note' => 'Messages from our team' ) as $type => $title ) :
										$rows = array_filter( $queue, function ( $q ) use ( $type ) { return $q['type'] === $type; } );
										if ( ! $rows ) { continue; } ?>
										<p><b><?php echo esc_html( $title ); ?></b></p><ul><?php foreach ( $rows as $q ) : ?><li><?php echo esc_html( trim( $q['label'] . ( $q['label'] && $q['text'] ? ': ' : '' ) . $q['text'] ) ); ?></li><?php endforeach; ?></ul>
									<?php endforeach; ?>
								</div></div>
								<form method="post" action="<?php echo $form_url; ?>" class="form-actions"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="send"><button class="btn btn-navy" type="submit">Send email</button></form>
							</div></details><p class="hint cf-tray-note">Not sent yet. Nothing is sent automatically: until someone presses Send, this shows on the dashboard under <b>Updates not sent</b>.</p>
						<?php endif; ?>
					</div>
			<?php if ( $dupes ) : ?>
				<div class="dup-card"><b>Possible duplicate</b>
					<?php foreach ( array_values( $dupes ) as $di => $dp ) : ?><?php if ( 3 === $di ) : ?><details class="dup-more"><summary class="link-btn"><?php echo esc_html( 'Show ' . ( count( $dupes ) - 3 ) . ' more' ); ?></summary><?php endif; ?><span>Same <?php echo esc_html( implode( ' and ', $dp['on'] ) ); ?> as <a href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $dp['id'] ) ) ); ?>"><?php echo esc_html( hcc_name( $dp['id'] ) . ' (' . hcc_meta( $dp['id'], 'ref' ) . ')' ); ?></a> · <?php echo esc_html( array( 'in_progress' => 'In progress', 'completed' => 'Staff completed', 'closed' => 'Withdrawn / not qualified' )[ hcc_state( $dp['id'] ) ] ); ?></span><?php endforeach; ?><?php echo count( $dupes ) > 3 ? '</details>' : ''; ?>
					<form method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="dup_ok"><button class="link-btn" type="submit">Checked: not a duplicate</button></form>
				</div>
			<?php endif; ?>

			<?php if ( hcc_field_get( 'closing' ) && ! $closed ) : ?>
				<form class="p-card close-panel" id="close" method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="close">
					<div class="p-card-head"><h2>Close this application</h2><a class="link-btn" href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $aid ) ) ); ?>">Cancel</a></div>
					<p class="hint">Moves the candidate to <b>Withdrawn / not qualified</b> on the dashboard. The profile and files are kept until the retention period ends.</p>
					<div class="form-grid">
						<fieldset class="f full"><legend>Outcome</legend><div class="radios"><?php foreach ( array( 'Withdrawn by candidate', 'Not qualified', 'Not suitable' ) as $i => $o ) : ?><label class="radio"><input type="radio" name="outcome" value="<?php echo esc_attr( $o ); ?>"<?php checked( 0, $i ); ?>><span><?php echo esc_html( $o ); ?></span></label><?php endforeach; ?></div></fieldset>
						<div class="f full"><label for="why">Reason</label><textarea id="why" name="why" required placeholder="e.g. No NMC registration; candidate took a permanent job."></textarea></div>
						<div class="f"><label for="cby">Signed off by</label><input type="text" id="cby" name="by" value="<?php echo esc_attr( $me ); ?>" required></div>
						<div class="f"><label for="cdate">Date</label><input type="date" id="cdate" name="date" value="<?php echo esc_attr( wp_date( 'Y-m-d' ) ); ?>"></div>
					</div>
					<div class="form-actions"><button class="btn btn-navy" type="submit">Close application</button></div>
				</form>
			<?php endif; ?>

			<?php if ( hcc_field_get( 'training' ) && 'in_progress' === $state && hcc_missing_training( $aid ) ) : ?>
				<form class="p-card ov-panel" id="train-panel" method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="train_queue">
					<div class="p-card-head"><h2>Training reminder</h2><a class="link-btn" href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $aid ) ) ); ?>">Cancel</a></div>
					<p class="hint">The ticked courses go into the update for <?php echo esc_html( hcc_meta( $aid, 'first' ) ); ?>, with the links to buy them on the e-learning portal. Press Send in the update tray to email it.</p>
					<div class="tsel">
						<?php foreach ( hcc_missing_training( $aid ) as $k => $label ) : ?><label class="radio"><input type="checkbox" name="tsel[]" value="<?php echo esc_attr( $k ); ?>" checked><span><?php echo esc_html( $label ); ?></span></label><?php endforeach; ?>
					</div>
					<div class="f full" style="margin-top:12px"><label for="tnote">Note (optional)</label><textarea id="tnote" name="note" placeholder="e.g. Fire Safety and First Aid are needed before your first shift on Monday."></textarea></div>
					<div class="form-actions"><button class="btn btn-navy" type="submit">Add to update</button></div>
				</form>
			<?php endif; ?>

			<?php if ( $ovkeys && isset( $items[ $ovkeys[0] ] ) ) : $ok = $ovkeys[0]; ?>
				<form class="p-card ov-panel" id="override" method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="override"><input type="hidden" name="keys" value="<?php echo esc_attr( implode( ',', $ovkeys ) ); ?>">
					<div class="p-card-head"><h2>Mark complete (override)</h2><span class="p-count">Item 1 of <?php echo count( $ovkeys ); ?></span></div>
					<p class="hint">Each item needs a reason and a note. Your name, the reason and the note are saved in the activity log.</p>
					<div class="ov-item"><?php echo esc_html( $items[ $ok ]['label'] ); ?></div>
					<div class="form-grid" style="margin-top:12px">
						<div class="f"><label for="ovr">Reason</label><select id="ovr" name="reason"><?php foreach ( hcc_override_reasons() as $o ) : ?><option><?php echo esc_html( $o ); ?></option><?php endforeach; ?></select></div>
						<div class="f full"><label for="ovn">Note (required)</label><textarea id="ovn" name="note" placeholder="e.g. Original passport checked in the Leeds office, copy on file."></textarea></div>
					</div>
					<div class="form-actions"><button class="btn btn-navy" type="submit"><?php echo count( $ovkeys ) > 1 ? 'Confirm and next' : 'Confirm'; ?></button><button class="link-btn" type="submit" name="skip" value="1">Skip this item</button><a class="link-btn" href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $aid ) ) ); ?>">Cancel</a></div>
				</form>
			<?php endif; ?>

			<?php if ( 'closed' === $state ) : ?>
				<div class="finish-card closed"><div><b><?php echo esc_html( $closed['outcome'] ); ?></b><span><?php echo esc_html( 'Closed ' . $closed['date'] . ' by ' . $closed['by'] . '. ' . $closed['why'] ); ?></span></div></div>
			<?php elseif ( 'completed' === $state ) : ?>
				<div class="finish-card complete"><div><b>Onboarding complete</b><span><?php echo esc_html( 'Signed off by ' . $completed['by'] . ' on ' . wp_date( 'j M Y, H:i', (int) $completed['at'] ) . '. Moved to Staff completed.' ); ?></span></div></div>
			<?php else :
				$can = hcc_can_finish( $aid ); ?>
				<form class="finish-card<?php echo $can ? ' ready' : ''; ?>" method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="finish">
					<div><b>Finish onboarding</b><span><?php echo esc_html( implode( '   ', array( ( 100 === $pct ? '✓' : '✗' ) . ' Profile ' . $pct . '%', ( hcc_meta( $aid, 'dec_sent' ) ? '✓' : '✗' ) . ' Declaration sent', ( hcc_meta( $aid, 'dec_signed' ) ? '✓' : '✗' ) . ' Signed declaration received', ( $queue ? '✗ ' . count( $queue ) . ' update(s) not sent' : '✓ No unsent updates' ) ) ) ); ?></span></div>
					<div class="finish-act"><input type="text" name="by" value="<?php echo esc_attr( $me ); ?>" aria-label="Signed off by"><button class="btn btn-navy btn-sm" type="submit"<?php disabled( ! $can ); ?>>Finish onboarding and move to Staff completed</button></div>
				</form>
			<?php endif; ?>
			<div class="cf-body">
				<nav class="cf-nav" aria-label="Candidate file">
					<?php foreach ( $fnav as $fi ) : ?><a class="cf-link" href="#<?php echo esc_attr( $fi[0] ); ?>" data-cf="<?php echo esc_attr( $fi[0] ); ?>"><span><?php echo esc_html( $fi[1] ); ?></span><?php echo $fi[2]; // phpcs:ignore ?></a><?php endforeach; ?>
				</nav>
				<div class="cf-main">
				<div class="sec-toggle"><button class="link-btn" type="button" data-sections="open">Open all sections</button> · <button class="link-btn" type="button" data-sections="close">Close all</button></div>
					<details open class="p-sec p-card" id="answers">
						<summary class="p-card-head"><h2>Profile</h2><span class="p-count">Contact details and everything they told us</span></summary>
							<div class="cf-facts">
								<?php foreach ( array( 'Email' => hcc_meta( $aid, 'email' ), 'Mobile' => hcc_meta( $aid, 'phone' ), 'Reference' => hcc_meta( $aid, 'ref' ), 'Role applied for' => $role_label( $aid ), 'Registered' => wp_date( 'j M Y, H:i', hcc_started( $aid ) ), 'Stage' => hcc_meta( $aid, 'submitted' ) ? hcc_meta( $aid, 'stage', 'Documents' ) : 'Registering (step ' . (int) hcc_meta( $aid, 'step', 1 ) . ' of 7)' ) as $fk => $fv ) : ?><div><small><?php echo esc_html( $fk ); ?></small><span><?php echo esc_html( '' !== (string) $fv ? $fv : '—' ); ?></span></div><?php endforeach; ?>
							</div>
						<details class="email-fix cf-email"><summary>Change email address</summary>
							<form method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="email">
								<p class="hint">Now: <b><?php echo esc_html( hcc_meta( $aid, 'email' ) ); ?></b>. The new email becomes their login. Both addresses get a notice.</p>
								<div class="f"><label for="sne">New email address</label><input type="email" id="sne" name="new_email" required></div>
								<div class="form-actions" style="margin-top:8px"><button class="btn btn-ghost btn-sm" type="submit">Change email</button></div>
							</form>
						</details>
							<p class="cf-sub">Pre-screening answers</p>
						<?php $i = 0;
						foreach ( hcc_answer_groups( $aid, false ) as $title => $rows ) : ?>
							<details class="det"<?php echo $i++ < 1 ? ' open' : ''; ?>><summary><?php echo esc_html( $title ); ?></summary><dl><?php foreach ( $rows as $k => $v ) : ?><div><dt><?php echo esc_html( $k ); ?></dt><dd><?php echo esc_html( '' !== (string) $v ? $v : '—' ); ?></dd></div><?php endforeach; ?></dl></details>
						<?php endforeach; ?>
					</details>
					<details class="p-sec p-card bank-card" id="bank">
						<summary class="p-card-head"><h2>Bank details</h2><span class="p-count"><?php echo hcc_is_manager() ? 'Managers only' : 'Last 4 digits'; ?></span></summary>
						<dl class="bank-dl">
							<?php $bank = hcc_answer_groups( $aid, true )['Bank details'];
							if ( ! hcc_is_manager() ) {
								$bank['Sort code']      = $bank['Sort code'] ? '**-**-' . substr( $bank['Sort code'], -2 ) : '';
								$bank['Account number'] = $bank['Account number'] ? '****' . substr( $bank['Account number'], -4 ) : '';
							}
							foreach ( $bank as $k => $v ) : ?><div><dt><?php echo esc_html( $k ); ?></dt><dd><?php echo esc_html( $v ? $v : '—' ); ?></dd></div><?php endforeach; ?>
						</dl>
					</details>
					<form method="post" action="<?php echo $form_url; ?>" id="documents" class="items-form"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="items">
					<?php foreach ( array( 'docs' => 'Documents', 'train' => 'Training certificates' ) as $set => $title ) :
						$list = hcc_items( $aid, $set );
						$c    = hcc_counts( $aid, $list );
						$sum  = $c['need'] . ' items · ' . $c['ok'] . ' approved · ' . $c['review'] . ' to review · ' . $c['todo'] . ' missing' . ( $c['amend'] ? ' · ' . $c['amend'] . ' to replace' : '' );
						?>
						<details open class="p-sec p-card" id="sec-<?php echo esc_attr( $set ); ?>">
							<?php if ( 'docs' === $set ) : ?>
								<summary class="p-card-head"><h2>Documents</h2><span class="p-count"><?php echo esc_html( $sum ); ?></span></summary>
								<div class="bulk"><span>With ticked items:</span><button class="btn btn-sm btn-aqua" type="submit" name="act" value="bulk:approve">Approve</button><button class="btn btn-sm btn-sun" type="submit" name="act" value="bulk:missing">Request as missing</button><button class="btn btn-sm btn-ghost-light" type="submit" name="act" value="bulk:override">Mark complete (override)</button></div>
							<?php else : ?>
								<summary class="p-card-head"><h2>Training certificates</h2><span class="p-count"><?php echo esc_html( $sum ); ?></span></summary>
								<div class="bulk"><span>With ticked items:</span><button class="btn btn-sm btn-aqua" type="submit" name="act" value="bulk:approve">Approve</button><button class="btn btn-sm btn-sun" type="submit" name="act" value="bulk:missing">Request as missing</button><button class="btn btn-sm btn-ghost-light" type="submit" name="act" value="bulk:override">Mark complete (override)</button></div>
								<?php $tmiss = hcc_missing_training( $aid ); $trem = hcc_meta( $aid, 'train_reminded' ); ?>
								<div class="train-remind"><span><?php echo $tmiss ? esc_html( count( $tmiss ) . ' training certificate' . ( count( $tmiss ) > 1 ? 's' : '' ) . ' still to come.' ) : 'No training certificates missing.'; ?><?php echo is_array( $trem ) ? ' <small>' . esc_html( 'Last reminder ' . wp_date( 'j M Y', (int) $trem['at'] ) . ' by ' . $trem['by'] . ' (' . (int) $trem['n'] . ' course' . ( (int) $trem['n'] > 1 ? 's' : '' ) . ')' ) . '</small>' : ''; // phpcs:ignore ?></span><?php if ( $tmiss && 'in_progress' === $state ) : ?><a class="btn btn-sm btn-sun" href="<?php echo esc_url( hcc_staff_url( array( 'candidate' => $aid, 'training' => 1 ) ) ); ?>#train-panel">Send training reminder</a><?php endif; ?></div>
							<?php endif; ?>
							<div class="s-table">
							<?php foreach ( $list as $k => $it ) :
								$s  = hcc_item_status( $aid, $k, $it );
								$st = hcc_file_state( $aid, $k );
								$r  = isset( $review[ $k ] ) ? $review[ $k ] : array();
								?>
								<div class="s-row s-<?php echo esc_attr( $s ); ?>" id="item-<?php echo esc_attr( $k ); ?>">
									<?php if ( 'na' === $s ) : ?><span class="s-cb"></span><?php else : ?><label class="s-cb"><input type="checkbox" name="sel[]" value="<?php echo esc_attr( $k ); ?>" aria-label="Select <?php echo esc_attr( $it['label'] ); ?>"></label><?php endif; ?>
									<div class="s-item"><b><?php echo esc_html( $it['label'] ); ?></b>
										<?php foreach ( isset( $st['files'] ) ? $st['files'] : array() as $n => $f ) : ?>
											<span class="f-line"><a class="p-file f-view" href="<?php echo esc_url( hcc_file_url( $aid, $k, $n ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $f['name'] ); ?></a><a class="f-act" href="<?php echo esc_url( hcc_file_url( $aid, $k, $n ) ); ?>" target="_blank" rel="noopener">View</a><a class="f-act" href="<?php echo esc_url( hcc_file_url( $aid, $k, $n, true ) ); ?>">Download</a></span>
										<?php endforeach; ?>
										<?php if ( ! empty( $st['pin'] ) ) : ?><span class="p-file">PIN <?php echo esc_html( $st['pin'] ); ?> · <a href="https://www.nmc.org.uk/registration/search-the-register/" target="_blank" rel="noopener">check NMC register</a></span><?php endif; ?>
										<?php echo hcc_exp_staff_line( $aid, $k, $st, $it ); // phpcs:ignore ?>
										<?php if ( ! empty( $st['missing'] ) && ! hcc_has_upload( $st ) && ! in_array( $s, array( 'approved', 'override' ), true ) ) : ?><span class="p-file">Candidate ticked "I don't have this yet"</span><?php endif; ?>
										<?php if ( 'na' === $s && ! empty( $it['note'] ) ) : ?><span class="p-file" style="color:var(--muted)"><?php echo esc_html( $it['note'] ); ?></span><?php endif; ?>
										<?php if ( ! empty( $r['reason'] ) ) : ?><span class="<?php echo 'override' === $s ? 'p-ov' : 'p-reason'; ?>"><?php echo esc_html( ( 'override' === $s ? 'Override: ' : '' ) . $r['reason'] . ( ! empty( $r['by'] ) ? ' · ' . $r['by'] : '' ) ); ?></span><?php endif; ?>
										<?php foreach ( isset( $dnotes[ $k ] ) ? $dnotes[ $k ] : array() as $n ) : ?><span class="d-note<?php echo $n['internal'] ? ' internal' : ''; ?>"><?php echo esc_html( ( $n['internal'] ? 'Internal' : 'To candidate' ) . ' · ' . $n['by'] . ': ' . $n['text'] ); ?></span><?php endforeach; ?>
									</div>
									<?php echo hcc_status_chip( $s, 'staff' ); // phpcs:ignore ?>
									<?php if ( 'na' !== $s ) : ?>
									<span class="s-btns">
										<?php if ( in_array( $s, array( 'review', 'amend' ), true ) ) : ?><button type="submit" class="mini ok" name="act" value="approve:<?php echo esc_attr( $k ); ?>" title="Approve" aria-label="Approve <?php echo esc_attr( $it['label'] ); ?>">✓</button><?php endif; ?>
										<details class="mini-pop"><summary class="mini <?php echo hcc_has_upload( $st ) ? 'am' : 'nt'; ?>" title="Ask to replace or add a note" aria-label="More actions">⋯</summary>
											<div class="pop">
												<?php if ( hcc_has_upload( $st ) ) : ?>
													<label>Ask to replace<select name="reason[<?php echo esc_attr( $k ); ?>]"><?php foreach ( hcc_amend_reasons() as $o ) : ?><option><?php echo esc_html( $o ); ?></option><?php endforeach; ?></select></label>
													<button type="submit" class="btn btn-sm btn-sun" name="act" value="amend:<?php echo esc_attr( $k ); ?>">Ask candidate to replace</button>
												<?php endif; ?>
												<label>Note<input type="text" name="dnote[<?php echo esc_attr( $k ); ?>]" placeholder="Note about this document"></label>
												<div class="note-btns"><button type="submit" class="btn btn-sm btn-sun" name="act" value="notec:<?php echo esc_attr( $k ); ?>">Add to update for candidate</button><button type="submit" class="btn btn-sm btn-ghost" name="act" value="note:<?php echo esc_attr( $k ); ?>">Save as staff-only note</button></div>
											</div>
										</details>
									</span>
									<?php else : ?><span></span><?php endif; ?>
								</div>
							<?php endforeach; ?>
							</div>
						</details>
					<?php endforeach; ?>
					</form>
					<?php
					$seen_before = (int) hcc_meta( $aid, 'cmsg_seen', 0 );
					$unread      = hcc_unread_msgs( $aid );
					$thread      = hcc_thread( $aid );
					if ( $unread ) {
						hcc_set( $aid, 'cmsg_seen', time() );
						hcc_log( $aid, 'Opened ' . $unread . ' new message' . ( $unread > 1 ? 's' : '' ) . ' from the candidate' );
					}
					?>
					<details class="p-sec p-card" id="messages"<?php echo $thread ? ' open' : ''; ?>>
						<summary class="p-card-head"><h2>Messages<?php echo $unread ? ' <em class="new-msg-tag">' . (int) $unread . ' new</em>' : ''; ?></h2><span class="p-count">With the candidate</span></summary>
						<?php if ( $thread ) : ?>
							<ol class="thread">
								<?php foreach ( array_slice( $thread, -30 ) as $m ) : ?>
									<li class="<?php echo esc_attr( $m['from'] ) . ( 'cand' === $m['from'] && $m['at'] > $seen_before ? ' new' : '' ); ?>"><span class="who"><?php echo esc_html( ( 'cand' === $m['from'] ? hcc_meta( $aid, 'first' ) : $m['by'] ) . ' · ' . wp_date( 'j M, H:i', $m['at'] ) . ( $m['label'] ? ' · about ' . $m['label'] : '' ) ); ?></span><?php echo nl2br( esc_html( $m['text'] ) ); ?></li>
								<?php endforeach; ?>
							</ol>
						<?php else : ?>
							<p class="hint">No messages yet. Candidates can write to you from their portal.</p>
						<?php endif; ?>
						<form method="post" action="<?php echo $form_url; ?>" class="msg-form"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="cnote"><input type="hidden" name="type" value="cand"><input type="hidden" name="by" value="<?php echo esc_attr( $me ); ?>"><input type="hidden" name="back" value="messages">
							<label for="mreply" class="screen-reader-text">Reply</label>
							<textarea id="mreply" name="text" rows="2" placeholder="Reply to <?php echo esc_attr( hcc_meta( $aid, 'first' ) ); ?>…" required></textarea>
							<div class="form-actions" style="margin-top:8px"><button class="btn btn-navy btn-sm" type="submit">Add reply to update</button><span class="form-note">Goes out with the next update email when you press Send.</span></div>
						</form>
					</details>
					<details class="p-sec p-card" id="checks"<?php echo $chk_n < count( $chk_all ) ? ' open' : ''; ?>>
						<summary class="p-card-head"><h2>Checks</h2><span class="p-count">Who checked, when, result</span></summary>
						<?php $checks = (array) hcc_meta( $aid, 'checks', array() );
						foreach ( hcc_check_list( $aid ) as $k => $c ) :
							$v = isset( $checks[ $k ] ) ? $checks[ $k ] : array(); ?>
							<details class="chk"><summary><span><b><?php echo esc_html( $c[0] ); ?></b><small><?php echo esc_html( $c[1] ); ?></small></span><?php echo ! empty( $v['result'] ) ? '<span class="stat stat-' . ( 'Pass' === $v['result'] ? 'ok' : ( 'Fail' === $v['result'] ? 'amend' : 'todo' ) ) . '">' . esc_html( $v['result'] ) . '</span>' : '<span class="stat stat-wait">Not checked</span>'; // phpcs:ignore ?></summary>
								<?php if ( ! empty( $v['result'] ) ) : ?><p class="chk-done">Checked <?php echo esc_html( $v['date'] . ' by ' . $v['by'] . ( $v['outcome'] ? ' · ' . $v['outcome'] : '' ) . ( ! empty( $v['visa_exp'] ) ? ' · Visa expires ' . wp_date( 'd/m/Y', strtotime( $v['visa_exp'] ) ) : '' ) ); ?></p><?php endif; ?>
								<form class="form-grid chk-form" method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="check"><input type="hidden" name="k" value="<?php echo esc_attr( $k ); ?>">
									<div class="f"><label>Date checked</label><input type="date" name="date" value="<?php echo esc_attr( ! empty( $v['date'] ) ? $v['date'] : wp_date( 'Y-m-d' ) ); ?>"></div>
									<div class="f"><label>Checked by</label><input type="text" name="by" value="<?php echo esc_attr( ! empty( $v['by'] ) ? $v['by'] : $me ); ?>"></div>
									<div class="f"><label>Result</label><select name="result"><option value="">Choose</option><?php foreach ( array( 'Pass', 'Fail', 'Follow-up needed' ) as $o ) : ?><option<?php selected( isset( $v['result'] ) ? $v['result'] : '', $o ); ?>><?php echo esc_html( $o ); ?></option><?php endforeach; ?></select></div>
									<?php if ( $c[3] ) : ?><div class="f"><label>Visa expiry date</label><input type="date" name="visa_exp" value="<?php echo esc_attr( isset( $v['visa_exp'] ) ? $v['visa_exp'] : '' ); ?>"></div><?php endif; ?>
									<div class="f full"><label>Outcome / notes</label><input type="text" name="outcome" value="<?php echo esc_attr( isset( $v['outcome'] ) ? $v['outcome'] : '' ); ?>" placeholder="e.g. Right to work confirmed, no restrictions on hours"></div>
									<div class="form-actions full" style="margin-top:0"><?php if ( $c[2] ) : ?><a class="link-btn" href="<?php echo esc_url( $c[2] ); ?>" target="_blank" rel="noopener">Open official check ↗</a><?php endif; ?><button class="btn btn-ghost btn-sm" type="submit">Save check</button></div>
								</form>
							</details>
						<?php endforeach; ?>
					</details>
					<details class="p-sec p-card" id="refs"<?php echo $refs_n < count( $refs_l ) ? ' open' : ''; ?>>
						<summary class="p-card-head"><h2>References</h2><span class="p-count">Sent and checked manually</span></summary>
						<?php foreach ( hcc_refs( $aid ) as $i => $rf ) :
							$stc = $rf['recv'] ? '<span class="stat stat-' . ( 'Concerns' === $rf['outcome'] ? 'amend' : 'ok' ) . '">Received ' . esc_html( wp_date( 'd/m/Y', strtotime( $rf['recv'] ) ) ) . '</span>' : ( $rf['sent'] ? '<span class="stat stat-wait">Sent ' . esc_html( wp_date( 'd/m/Y', strtotime( $rf['sent'] ) ) ) . '</span>' : '<span class="stat stat-todo">Not sent</span>' ); ?>
							<details class="chk"><summary><span><b>Referee <?php echo (int) $i + 1; ?>: <?php echo esc_html( $rf['name'] ? $rf['name'] : 'not given' ); ?></b><small><?php echo esc_html( implode( ' · ', array_filter( array( $rf['pos'], $rf['email'], $rf['phone'] ) ) ) ); ?></small><?php if ( ! empty( $rf['history'] ) ) : ?><small class="ref-hist">Replaced <?php echo count( $rf['history'] ); ?>×. Previous: <?php echo esc_html( implode( ', ', wp_list_pluck( $rf['history'], 'name' ) ) ); ?></small><?php endif; ?></span><?php echo $stc; // phpcs:ignore ?></summary>
								<form class="form-grid chk-form" method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="ref"><input type="hidden" name="i" value="<?php echo (int) $i; ?>">
									<div class="f"><label>Reference sent on</label><input type="date" name="sent" value="<?php echo esc_attr( $rf['sent'] ); ?>"></div>
									<div class="f"><label>Reference received on</label><input type="date" name="recv" value="<?php echo esc_attr( $rf['recv'] ); ?>"></div>
									<div class="f"><label>Outcome</label><select name="outcome"><option value="">Choose</option><?php foreach ( array( 'Satisfactory', 'Concerns', 'Not received' ) as $o ) : ?><option<?php selected( $rf['outcome'], $o ); ?>><?php echo esc_html( $o ); ?></option><?php endforeach; ?></select></div>
									<div class="form-actions full" style="margin-top:0"><button class="btn btn-ghost btn-sm" type="submit">Save</button></div>
								</form>
								<details class="ref-new-wrap"><summary class="link-btn">Replace referee (new details)</summary>
									<form class="ref-new" method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="ref_replace"><input type="hidden" name="i" value="<?php echo (int) $i; ?>">
										<div class="form-grid"><div class="f"><label>Full name</label><input type="text" name="name" required></div><div class="f"><label>Position and organisation</label><input type="text" name="pos"></div><div class="f"><label>Email</label><input type="email" name="email"></div><div class="f"><label>Phone</label><input type="tel" name="phone"></div></div>
										<div class="form-actions" style="margin-top:8px"><button class="btn btn-navy btn-sm" type="submit">Save new referee</button></div>
									</form>
								</details>
							</details>
						<?php endforeach; ?>
						<details class="ref-new-wrap" style="margin-top:10px"><summary class="link-btn">+ Add another referee</summary>
							<form class="ref-new" method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="ref_add">
								<div class="form-grid"><div class="f"><label>Full name</label><input type="text" name="name" required></div><div class="f"><label>Position and organisation</label><input type="text" name="pos"></div><div class="f"><label>Email</label><input type="email" name="email"></div><div class="f"><label>Phone</label><input type="tel" name="phone"></div></div>
								<div class="form-actions" style="margin-top:8px"><button class="btn btn-navy btn-sm" type="submit">Add referee</button></div>
							</form>
						</details>
					</details>
					<?php do_action( 'hcc_staff_folder_side', $aid, $form_url ); ?>
					<?php if ( has_action( 'hcc_staff_folder_declaration' ) ) : do_action( 'hcc_staff_folder_declaration', $aid, $form_url ); else : ?>
					<details open class="p-sec p-card" id="declaration">
						<summary class="p-card-head"><h2>Declaration</h2><span class="p-count">Sent manually</span></summary>
						<form method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="dec">
							<p class="hint" style="margin-bottom:10px">Send the declaration once all documents are approved, then record it here.</p>
							<label class="consent"><input type="checkbox" name="dec_sent" value="1"<?php checked( (bool) hcc_meta( $aid, 'dec_sent' ) ); ?>>Declaration sent to candidate<?php echo hcc_meta( $aid, 'dec_sent' ) ? ' (' . esc_html( wp_date( 'j M', (int) hcc_meta( $aid, 'dec_sent' ) ) ) . ')' : ''; ?></label>
							<label class="consent" style="margin-top:8px"><input type="checkbox" name="dec_signed" value="1"<?php checked( (bool) hcc_meta( $aid, 'dec_signed' ) ); ?>>Signed declaration received<?php echo hcc_meta( $aid, 'dec_signed' ) ? ' (' . esc_html( wp_date( 'j M', (int) hcc_meta( $aid, 'dec_signed' ) ) ) . ')' : ''; ?></label>
							<div class="form-actions" style="margin-top:10px"><button class="btn btn-ghost btn-sm" type="submit">Save</button></div>
						</form>
					</details>
					<?php endif; ?>
					<details class="p-sec p-card" id="notes">
						<summary class="p-card-head"><h2>Notes</h2></summary>
						<form method="post" action="<?php echo $form_url; ?>"><?php echo $hidden; // phpcs:ignore ?><input type="hidden" name="do" value="cnote">
							<div class="radios note-type"><label class="radio"><input type="radio" name="type" value="internal" checked><span>Internal compliance note</span></label><label class="radio"><input type="radio" name="type" value="cand"><span>Message to candidate</span></label></div>
							<div class="f" style="margin-top:10px"><label for="ntext">Note</label><textarea id="ntext" name="text" placeholder="Internal notes are staff only. Messages go in the next update email."></textarea></div>
							<div class="form-grid" style="margin-top:10px">
								<div class="f"><label for="nby">Signed off by</label><input type="text" id="nby" name="by" value="<?php echo esc_attr( $me ); ?>"></div>
								<div class="f"><label for="ndue">Next action due</label><input type="date" id="ndue" name="due"></div>
								<div class="f full"><label for="nnext">Next action for candidate (optional)</label><input type="text" id="nnext" name="next" placeholder="e.g. Chase NI letter on Friday"></div>
							</div>
							<div class="form-actions" style="margin-top:10px"><button class="btn btn-ghost btn-sm" type="submit">Save to profile</button></div>
						</form>
						<div class="cnotes">
							<?php foreach ( array_reverse( (array) hcc_meta( $aid, 'cnotes', array() ) ) as $n ) : ?>
								<div class="cnote<?php echo 'cand' === $n['type'] ? ' cand' : ''; ?>"><div class="cn-h"><b><?php echo 'cand' === $n['type'] ? 'Message to candidate' : 'Internal note'; ?></b><span><?php echo esc_html( wp_date( 'j M, H:i', (int) $n['at'] ) . ( $n['by'] ? ' · signed off by ' . $n['by'] : '' ) ); ?></span></div><p><?php echo esc_html( $n['text'] ); ?></p><?php if ( $n['next'] ) : ?><span class="cn-next">Next action: <?php echo esc_html( $n['next'] . ( $n['due'] ? ' · due ' . wp_date( 'd/m/Y', strtotime( $n['due'] ) ) : '' ) ); ?></span><?php endif; ?></div>
							<?php endforeach; ?>
						</div>
					</details>
					<?php $sent = array_reverse( (array) hcc_meta( $aid, 'messages', array() ) ); ?>
					<details class="p-sec p-card" id="sent">
						<summary class="p-card-head"><h2>Sent to candidate</h2><span class="p-count"><?php echo $sent ? count( $sent ) . ' update' . ( count( $sent ) > 1 ? 's' : '' ) . ' · also shown in their portal' : 'Nothing sent yet'; ?></span></summary>
						<?php foreach ( $sent as $m ) : ?>
							<div class="sent-item"><b><?php echo esc_html( wp_date( 'j M Y, H:i', (int) $m['at'] ) . ( ! empty( $m['by'] ) ? ' · ' . $m['by'] : '' ) ); ?></b><ul>
								<?php foreach ( (array) $m['items'] as $q ) : ?><li><span class="sent-t sent-<?php echo esc_attr( $q['type'] ); ?>"><?php echo esc_html( array( 'approved' => 'Approved', 'amend' => 'Replace', 'missing' => 'Needed', 'training' => 'Training', 'note' => 'Message' )[ $q['type'] ] ?? $q['type'] ); ?></span> <?php echo esc_html( trim( $q['label'] . ( $q['label'] && $q['text'] ? ': ' : '' ) . $q['text'] ) ); ?></li><?php endforeach; ?>
							</ul></div>
						<?php endforeach; ?>
					</details>
					<details class="p-sec p-card" id="activity">
						<summary class="p-card-head"><h2>Activity log</h2></summary>
						<ol class="timeline">
							<?php foreach ( array_reverse( (array) hcc_meta( $aid, 'log', array() ) ) as $l ) : ?><li><b><?php echo esc_html( $l['text'] ); ?></b><span><?php echo esc_html( wp_date( 'j M, H:i', (int) $l['time'] ) . ' · ' . ( is_string( $l['by'] ) ? $l['by'] : '' ) ); ?></span></li><?php endforeach; ?>
						</ol>
					</details>
				</div>
			</div>
<?php endif; ?>
<?php hcc_app_close(); ?>
</main>
<?php
get_footer();
